import Navbar from '../components/Projects/Navbar/Navbar3'; 
import Body from '../components/Editor/body';  

const Editor = () => {
return (
    <> 
    <Navbar /> 
    <Body />
    </>
);
};

export default Editor