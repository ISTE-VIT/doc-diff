import Navbar2 from "../components/Login/Navbar/Navbar2"
import LoginBody from "../components/Login/body/loginBody"


const Login = () => {
    return(
        <>
        <Navbar2 />
        <LoginBody />
        </>
    )
}

export default Login;
