import Navbar2 from "../components/Login/Navbar/Navbar2"
import SignupBody from "../components/Signup/body/signupBody"



const Signup = () => {
    return(
        <>
        <Navbar2 />
        <SignupBody />
        </>
    )
}

export default Signup;
