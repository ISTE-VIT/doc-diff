import Navbar3 from "../components/Projects/Navbar/Navbar3"
import Section4 from '../components/Projects/Section4/section4'; 

const Projects = () => {
return(
    <>
    <Navbar3/>
    <Section4/>
    </>
 )
};

export default Projects
